#17/02/21
#What does this code do?
#The purpose of this code is to use the "print()" function to display the string "Hello, World!"
#The "print()" function is designed to display either a predefined variable, or a string of text.

print("Hello, World!")

#What is happening here?
#In this example, the function is "print" and the variable, or input is the string "Hello, World!"
