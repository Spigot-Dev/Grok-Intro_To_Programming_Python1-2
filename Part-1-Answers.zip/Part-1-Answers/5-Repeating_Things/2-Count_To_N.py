#17/02/21
#What does this code do?
#	This code takes an input "n" and counts out until that number is reached.
#	This works similarly to the previous code, except with numbers. 

n = int(input('Enter a number: '))
for i in range(n):
  print(i + 1)
  
#What is happening here?
#	In line 1, our code is taking an integer input, and assigning it to "n"
#	After that, it prints i+1, until n is reached. 

